export default function Agents() {
  return <div style={{padding:24}}>Agents list (placeholder) — connect to backend /agents endpoint.</div>
}
