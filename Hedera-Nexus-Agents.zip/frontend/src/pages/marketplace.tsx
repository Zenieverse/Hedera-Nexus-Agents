export default function Marketplace() {
  return <div style={{padding:24}}>Marketplace (placeholder) — connect to backend /marketplace endpoints.</div>
}
