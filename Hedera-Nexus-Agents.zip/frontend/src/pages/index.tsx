import Head from 'next/head'
export default function Home() {
  return (
    <div style={{padding:24, fontFamily:'Inter, system-ui'}}>
      <Head><title>Hedera Nexus Agents</title></Head>
      <h1>Hedera Nexus Agents — Marketplace</h1>
      <p>This demo UI lists registered agents and marketplace listings. It is a stub for hackathon judges.</p>
      <p>Run the backend and visit API endpoints to see live data.</p>
    </div>
  )
}
