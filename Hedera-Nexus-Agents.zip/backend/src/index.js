/**
 * Simple backend stub for Hedera Nexus Agents
 * - Provides agent registration endpoints (off-chain wrapper around on-chain registry)
 * - Marketplace endpoints to create & complete listings (coordinated with smart contracts)
 * - HCS proof logging responsibilities are noted in comments
 */

require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.json());

// In-memory demo store (replace with DB in prod)
const agents = {};
const listings = [];

// Health
app.get('/health', (req, res) => res.json({status:'ok'}));

// Register agent (this should call the AgentRegistry contract in production)
app.post('/agents/register', (req, res) => {
  const {address, metadata} = req.body;
  if (!address || !metadata) return res.status(400).json({error:'address and metadata required'});
  agents[address] = metadata;
  return res.json({address, metadata});
});

// List agents
app.get('/agents', (req, res) => res.json(Object.keys(agents).map(a=>({address:a, metadata:agents[a]}))));

// Create marketplace listing (in real flow this will create on-chain listing)
app.post('/marketplace/create', (req, res) => {
  const {provider, description, price} = req.body;
  if (!provider || !description) return res.status(400).json({error:'provider and description required'});
  const id = listings.length;
  listings.push({id, provider, description, price, active:true});
  return res.json({id, provider, description, price});
});

// Complete listing (simulate A2A exchange completion and HCS logging)
app.post('/marketplace/complete', (req, res) => {
  const {id, consumer} = req.body;
  const l = listings[id];
  if (!l) return res.status(404).json({error:'listing not found'});
  if (!l.active) return res.status(400).json({error:'listing completed or inactive'});
  l.active = false;
  // TODO: In production: call Hedera HTS transfer, publish HCS proof
  return res.json({id, consumer, status:'completed'});
});

const PORT = process.env.PORT || 8000;
app.listen(PORT, ()=>console.log('Backend running on port', PORT));
