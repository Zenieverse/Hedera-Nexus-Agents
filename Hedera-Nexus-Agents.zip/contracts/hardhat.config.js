require('@nomiclabs/hardhat-ethers');
module.exports = {
  solidity: '0.8.19',
  networks: {
    hardhat: {}
    // Add hedera-testnet network and plugin config as needed
  }
};
