#!/usr/bin/env bash
# Start backend and frontend locally (simple)
cd backend && npm install &
cd frontend && npm install &
echo "Installations started. Run backend: cd backend && npm start; frontend: cd frontend && npm run dev"
