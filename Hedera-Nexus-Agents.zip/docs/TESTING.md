# Testing & Evaluation Instructions

This document explains how to run tests and validate the project for judges.

## Requirements (local)
- Node 18+ and npm
- Hardhat (for contracts) — installed via `npm install` in contracts folder
- Docker (optional, for docker-compose)

## Contracts
1. Install deps
```bash
cd contracts
npm install
```
2. Run unit tests & compile
```bash
npx hardhat compile
npx hardhat test
```

## Backend
1. Install deps
```bash
cd backend
npm install
```
2. Run tests
```bash
npm test
```
3. Start service (requires .env configured)
```bash
npm start
```

## Frontend
1. Install deps
```bash
cd frontend
npm install
npm run dev
```
2. Visit http://localhost:3000

## End-to-end (manual check)
1. Deploy contracts to Hedera testnet (use `contracts/scripts/deploy.js` with Hardhat/hedera plugin)
2. Start backend and frontend, register two agents, create a marketplace listing, execute a simulated A2A exchange
3. Inspect HCS proof logging via Mirror Node (if deployed to testnet)

---
