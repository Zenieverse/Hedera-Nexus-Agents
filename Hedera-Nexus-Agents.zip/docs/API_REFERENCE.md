# API Reference (Backend)

## Health
GET /health

## Agents
POST /agents/register
  body: { address, metadata }

GET /agents

## Marketplace
POST /marketplace/create
  body: { provider, description, price }

POST /marketplace/complete
  body: { id, consumer }

Notes:
- These endpoints are stubs for local demo. In production, each action will be backed by contract calls and Hedera SDK interactions.
- Proof logging should publish to an HCS topic (see contracts/ and backend/src/services/hederaService.js)
