# Hedera Nexus Agents

Hedera Nexus Agents is a decentralized coordination and payment network for autonomous AI agents built on Hedera.  
This repository contains the full hackathon-ready scaffold: smart contracts, backend services, frontend UI, deployment files, and tests.

## What to submit to judges
- This repository contains runnable code and tests. Judges can inspect `contracts/`, `backend/`, and `frontend/` for implementation details.
- See `docs/TESTING.md` for how to run unit & integration checks.

---
