const { expect } = require('chai');
describe('NexusMarketplace', function() {
  it('should be a placeholder test', async function() {
    expect(true).to.equal(true);
  });
});
