/**
 * Hedera service wrapper using @hashgraph/sdk
 * Requires environment variables set in backend/.env or process.env:
 *   HEDERA_OPERATOR_ID, HEDERA_OPERATOR_KEY, MIRROR_NODE_URL
 *
 * This file provides:
 * - createClient(): returns a Hedera client connected to testnet or mainnet based on env
 * - publishProof(topicId, message): publishes message to HCS topic
 * - callContract: placeholder showing how to create a contract execute transaction
 *
 * IMPORTANT: This code expects you to `npm install @hashgraph/sdk` in backend.
 */

const { Client, TopicCreateTransaction, TopicMessageSubmitTransaction, Hbar, ContractExecuteTransaction, ContractCreateTransaction, AccountId, PrivateKey } = require('@hashgraph/sdk');
require('dotenv').config();

function createClient() {
  const operatorId = process.env.HEDERA_OPERATOR_ID;
  const operatorKey = process.env.HEDERA_OPERATOR_KEY;
  if (!operatorId || !operatorKey) {
    throw new Error('Missing HEDERA_OPERATOR_ID or HEDERA_OPERATOR_KEY in env');
  }
  // Default to testnet; allow MAINNET via HEDERA_NETWORK env
  const network = (process.env.HEDERA_NETWORK || 'testnet').toLowerCase();
  let client;
  if (network === 'mainnet') {
    client = Client.forMainnet();
  } else {
    client = Client.forTestnet();
  }
  client.setOperator(AccountId.fromString(operatorId), PrivateKey.fromString(operatorKey));
  return client;
}

module.exports = {
  async createTopicAndPublish(message) {
    const client = createClient();
    // Create topic (in production you'd reuse a known topic)
    const tx = await new TopicCreateTransaction().execute(client);
    const receipt = await tx.getReceipt(client);
    const topicId = receipt.topicId.toString();
    // Submit message
    const submit = await new TopicMessageSubmitTransaction({
      topicId,
      message: typeof message === 'string' ? message : JSON.stringify(message)
    }).execute(client);
    const seq = (await submit.getReceipt(client)).topicSequenceNumber.toInt();
    return { topicId, seq };
  },

  async publishProof(topicId, message) {
    const client = createClient();
    // Submit a message to an existing topicId
    const submit = await new TopicMessageSubmitTransaction({
      topicId,
      message: typeof message === 'string' ? message : JSON.stringify(message)
    }).execute(client);
    const seq = (await submit.getReceipt(client)).topicSequenceNumber.toInt();
    return { topicId, seq };
  },

  async callContractExample(contractId, abiEncodedData) {
    const client = createClient();
    // Example of executing a contract function (requires contract on Hedera)
    const tx = await new ContractExecuteTransaction()
      .setContractId(contractId)
      .setGas(100_000)
      .setFunctionParameters(abiEncodedData)
      .execute(client);
    const receipt = await tx.getReceipt(client);
    return receipt;
  }
};
