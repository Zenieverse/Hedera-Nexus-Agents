/**
 * Integration-style tests for backend features. To perform real Hedera tests,
 * set HEDERA_OPERATOR_ID and HEDERA_OPERATOR_KEY in backend/.env and HCS_TOPIC_ID if required.
 */

const hedera = require('../services/hederaService');

async function smokeTest() {
  console.log('Running smoke tests...');
  try {
    if (!process.env.HEDERA_OPERATOR_ID) {
      console.log('Hedera env not set; skipping network calls. Running local logic checks.');
    } else {
      console.log('Hedera env found; attempting to create topic and publish a test message (this will cost small HBARs on testnet).');
      const res = await hedera.createTopicAndPublish({test:'hello'});
      console.log('Hedera createTopicAndPublish response:', res);
    }
  } catch (e) {
    console.error('Error during hedra test:', e);
  }
  console.log('Smoke tests completed.');
}

smokeTest().catch(e=>{ console.error(e); process.exit(1); });
