require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const hedera = require('./services/hederaService');
const app = express();
app.use(bodyParser.json());

// In-memory demo store
const agents = {};
const listings = [];

// Health
app.get('/health', (req, res) => res.json({status:'ok'}));

// Register agent - will write to on-chain registry (in production)
app.post('/agents/register', async (req, res) => {
  try {
    const { address, metadata } = req.body;
    if (!address || !metadata) return res.status(400).json({error:'address and metadata required'});
    agents[address] = metadata;
    // Publish a proof message to HCS to record registration, if HEDERA env is set
    if (process.env.HEDERA_OPERATOR_ID && process.env.HEDERA_OPERATOR_KEY && process.env.HCS_TOPIC_ID) {
      const proof = { type: 'agent_register', address, metadata, ts: new Date().toISOString() };
      await hedera.publishProof(process.env.HCS_TOPIC_ID, proof);
    }
    return res.json({address, metadata});
  } catch (e) {
    console.error(e);
    return res.status(500).json({error: String(e)});
  }
});

app.get('/agents', (req, res) => res.json(Object.keys(agents).map(a=>({address:a, metadata:agents[a]}))));

// Create marketplace listing (simulate on-chain create)
app.post('/marketplace/create', async (req, res) => {
  try {
    const { provider, description, price } = req.body;
    if (!provider || !description) return res.status(400).json({error:'provider and description required'});
    const id = listings.length;
    listings.push({id, provider, description, price, active:true});
    // Optionally publish listing creation to HCS for audit
    if (process.env.HEDERA_OPERATOR_ID && process.env.HEDERA_OPERATOR_KEY && process.env.HCS_TOPIC_ID) {
      const proof = { type: 'listing_create', id, provider, description, price, ts: new Date().toISOString() };
      await hedera.publishProof(process.env.HCS_TOPIC_ID, proof);
    }
    return res.json({id, provider, description, price});
  } catch (e) {
    console.error(e);
    return res.status(500).json({error: String(e)});
  }
});

// Complete listing (simulate A2A transaction + HTS transfer)
app.post('/marketplace/complete', async (req, res) => {
  try {
    const { id, consumer } = req.body;
    const l = listings[id];
    if (!l) return res.status(404).json({error:'listing not found'});
    if (!l.active) return res.status(400).json({error:'listing completed or inactive'});
    // In production: execute HTS token transfer or HBAR transfer via Hedera SDK, then publish HCS proof
    l.active = false;
    if (process.env.HEDERA_OPERATOR_ID && process.env.HEDERA_OPERATOR_KEY && process.env.HCS_TOPIC_ID) {
      const proof = { type: 'listing_complete', id, consumer, provider: l.provider, ts: new Date().toISOString() };
      await hedera.publishProof(process.env.HCS_TOPIC_ID, proof);
    }
    return res.json({id, consumer, status:'completed'});
  } catch (e) {
    console.error(e);
    return res.status(500).json({error: String(e)});
  }
});

const PORT = process.env.PORT || 8000;
app.listen(PORT, ()=>console.log('Backend running on port', PORT));
