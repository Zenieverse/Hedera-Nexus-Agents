export default async function handler(req, res) {
  const apiRes = await fetch(process.env.BACKEND_URL?.replace(/\/$/, '') + '/agents/register', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(req.body)
  }).catch(e=>({ok:false, status:500, json:()=>({error:String(e)})}));
  if (!apiRes.ok) {
    const j = await apiRes.json().catch(()=>({error:'failed'}));
    return res.status(apiRes.status || 500).json(j);
  }
  const json = await apiRes.json();
  return res.status(200).json(json);
}
