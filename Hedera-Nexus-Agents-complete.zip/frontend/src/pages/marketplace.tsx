import { useState } from 'react';

export default function Marketplace() {
  const [provider, setProvider] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState(0);
  const [message, setMessage] = useState('');

  const create = async () => {
    const res = await fetch('/api/create-listing', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({provider, description, price})
    });
    const j = await res.json();
    setMessage(JSON.stringify(j));
  };

  return (
    <div style={{padding:24}}>
      <h2>Create Listing</h2>
      <label>Provider<br/><input value={provider} onChange={e=>setProvider(e.target.value)} style={{width:400}}/></label><br/>
      <label>Description<br/><input value={description} onChange={e=>setDescription(e.target.value)} style={{width:600}}/></label><br/>
      <label>Price<br/><input type='number' value={price} onChange={e=>setPrice(Number(e.target.value))} /></label><br/>
      <button onClick={create}>Create Listing</button>
      <pre>{message}</pre>
    </div>
  )
}
