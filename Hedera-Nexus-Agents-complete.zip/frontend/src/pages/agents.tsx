import { useState } from 'react';

export default function Agents() {
  const [address, setAddress] = useState('');
  const [metadata, setMetadata] = useState('');
  const [message, setMessage] = useState('');

  const register = async () => {
    const res = await fetch('/api/register-agent', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({address, metadata})
    });
    const j = await res.json();
    setMessage(JSON.stringify(j));
  };

  return (
    <div style={{padding:24}}>
      <h2>Register Agent</h2>
      <label>Address<br/><input value={address} onChange={e=>setAddress(e.target.value)} style={{width:400}}/></label><br/>
      <label>Metadata (JSON)<br/><textarea value={metadata} onChange={e=>setMetadata(e.target.value)} rows={6} style={{width:600}}/></label><br/>
      <button onClick={register}>Register</button>
      <pre>{message}</pre>
    </div>
  )
}
