import Head from 'next/head'
import Link from 'next/link'
export default function Home() {
  return (
    <div style={{padding:24, fontFamily:'Inter, system-ui'}}>
      <Head><title>Hedera Nexus Agents</title></Head>
      <h1>Hedera Nexus Agents — Marketplace</h1>
      <p>This demo UI lets you register agents and create marketplace listings.</p>
      <p><Link href="/agents">Agents</Link> • <Link href="/marketplace">Marketplace</Link></p>
    </div>
  )
}
