Frontend stub. To use with local backend, set BACKEND_URL env in development:
export BACKEND_URL=http://localhost:8000
Then run:
cd frontend && npm install && npm run dev
