# Hedera Nexus Agents (Complete)

This is a complete scaffold for the Hedera Nexus Agents project. It includes:
- Smart contracts (Solidity) for AgentRegistry and NexusMarketplace
- Backend with Hedera SDK integration
- Frontend with demo pages to register agents and create listings
- Docs and testing instructions

## Quickstart (local)
1. Configure backend/.env with Hedera operator keys and optional HCS_TOPIC_ID for proof logging
2. Start backend:
   cd backend && npm install && npm run dev
3. Start frontend (in separate shell):
   cd frontend && npm install && BACKEND_URL=http://localhost:8000 npm run dev
4. Use the UI at http://localhost:3000 to register agents and create listings.

## Notes for Judges
- All Hedera interactions are implemented in `backend/src/services/hederaService.js` using `@hashgraph/sdk`.
- Smart contracts are in `contracts/` and can be deployed via Hardhat.
- This scaffold aims to be judge-friendly: clear structure, runnable scripts, and documented tests in `docs/TESTING.md`.
